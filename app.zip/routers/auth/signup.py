# app/routers/auth/signup.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.department import Department
from app.models.role import Role
from app.schemas.department import DepartmentResponse
from app.schemas.role import RoleResponse
from app.schemas.user import SignupRequest, SignupResponse
from app.services.user_service import (
    INITIAL_PASSWORD,
    create_employee_with_member,
    create_external_with_member,
)

router = APIRouter(
    prefix="/auth", tags=["auth"]
)  # ← 반드시 최상단 전역 스코프에 있어야 함


@router.get("/lookup/departments", response_model=list[DepartmentResponse])
def list_departments(for_user: str = "EMPLOYEE", db: Session = Depends(get_db)):
    if for_user not in ("EMPLOYEE", "EXTERNAL"):
        for_user = "EMPLOYEE"
    rows = db.scalars(select(Department).order_by(Department.dept_no.asc())).all()
    if for_user == "EMPLOYEE":
        # 외부인 전용 부서 코드를 '10'으로 가정
        rows = [d for d in rows if d.dept_no != "10"]
    return rows


@router.get("/lookup/roles", response_model=list[RoleResponse])
def list_roles(for_user: str = "EMPLOYEE", db: Session = Depends(get_db)):
    rows = db.scalars(select(Role).order_by(Role.role_no.asc())).all()
    return rows


@router.get("/debug/ping_db")
def ping_db(db: Session = Depends(get_db)):
    v = db.execute(text("SELECT 1")).scalar()
    return {"select1": v}


@router.post("/signup", response_model=SignupResponse)
def signup(req: SignupRequest, db: Session = Depends(get_db)):
    try:
        if req.user_type == "EMPLOYEE":
            if not req.dept_no or not req.role_no:
                raise HTTPException(status_code=400, detail="부서/직책 코드는 필수입니다.")
            employee, member = create_employee_with_member(
                db,
                dept_no=req.dept_no,
                role_no=req.role_no,
                name=req.name,
                email=req.email,
                mobile=req.mobile,
            )
            db.commit()
            return SignupResponse(
                member_id=member.member_id,
                user_type="EMPLOYEE",
                login_id=member.login_id,
                initial_password=INITIAL_PASSWORD,
            )

        if req.user_type == "EXTERNAL":
            external, member = create_external_with_member(
                db,
                name=req.name,
                email=req.email,
                mobile=req.mobile,
                company=req.company,
            )
            db.commit()
            return SignupResponse(
                member_id=member.member_id,
                user_type="EXTERNAL",
                login_id=member.login_id,
                initial_password=INITIAL_PASSWORD,
            )

        raise HTTPException(status_code=400, detail="알 수 없는 사용자 유형")

    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400, detail="이미 사용 중인 정보(이메일/연락처/아이디)입니다."
        )
    except SQLAlchemyError:
        db.rollback()
        raise HTTPException(status_code=500, detail="DB 오류가 발생했습니다.")
